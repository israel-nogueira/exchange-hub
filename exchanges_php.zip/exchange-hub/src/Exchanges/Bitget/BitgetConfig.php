<?php
namespace IsraelNogueira\ExchangeHub\Exchanges\Bitget;

class BitgetConfig
{
    const BASE_URL = 'https://api.bitget.com';
}
