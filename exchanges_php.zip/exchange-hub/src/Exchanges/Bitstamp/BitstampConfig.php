<?php
namespace IsraelNogueira\ExchangeHub\Exchanges\Bitstamp;

class BitstampConfig
{
    const BASE_URL = 'https://www.bitstamp.net/api/v2';
}
