<?php
namespace IsraelNogueira\ExchangeHub\Exchanges\Gateio;

class GateioConfig
{
    const BASE_URL = 'https://api.gateio.ws/api/v4';
}
