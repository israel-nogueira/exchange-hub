<?php
namespace IsraelNogueira\ExchangeHub\Exchanges\Gemini;

class GeminiConfig
{
    const BASE_URL = 'https://api.gemini.com';
}
