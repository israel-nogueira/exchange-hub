<?php
namespace IsraelNogueira\ExchangeHub\Exchanges\Bitfinex;

class BitfinexConfig
{
    const BASE_URL = 'https://api.bitfinex.com';
}
