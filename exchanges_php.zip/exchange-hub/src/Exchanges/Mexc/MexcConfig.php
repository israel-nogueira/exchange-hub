<?php
namespace IsraelNogueira\ExchangeHub\Exchanges\Mexc;

class MexcConfig
{
    const BASE_URL = 'https://api.mexc.com';
}
